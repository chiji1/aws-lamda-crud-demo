import routes from "./routes";

module.exports = routes;
