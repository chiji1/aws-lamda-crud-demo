const AWS = require('aws-sdk');
const uuid =  require('uuid');
const { schemaCreate, schemaUpdate } = require('./model');
const { success, fail} = require('../utils')

const dynamoDb = new AWS.DynamoDB.DocumentClient();

export async function fetchRecords(req, res) {

}

export async function createRecords(req, res) {
    try {
        const data = req.body;
        const  { error } = schemaCreate.validate(data);
        if (error) {
            return fail(res, 422, `Error validating data. ${error.message}`);
        }

        const params = {
            TableName: 'ingredients',
            Items: {
                id: uuid.v1(),
                title: data.title,
                image: data.image,
                createdAt: new Date().toISOString()
            }
        }

        dynamoDb.put(params, (error, data) => {
            if (error) {
                console.log(error);
                return fail(res, 422, error);
            }

            return success(res, 200, data.Items, 'Ingredient created successfully');
        });
    } catch (e) {
        return fail(res, 400, `Error creating record. ${e.message}`);
    }
}

export async function updateRecords(req, res) {

}

export async function deleteRecords(req, res) {

}
